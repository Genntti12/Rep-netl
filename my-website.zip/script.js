console.log("Site loaded successfully!");
